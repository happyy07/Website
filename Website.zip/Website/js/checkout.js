var amount=document.querySelector('#amount');
amount.value='$'+localStorage.getItem("totalCost")+',00';